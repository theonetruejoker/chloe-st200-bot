module.exports = (bot, db, config, winston, userDocument, serverDocument, channelDocument, memberDocument, msg) => {
	msg.channel.createMessage("Music support coming soon™ 🎶");
};